# Phase 1 — Vite WebSocket repair

## Log diagnosis
- Express backend starts on port 3000.
- Vite browser client fails to establish its HMR WebSocket. This is consistent with a cloud IDE/reverse-proxy preview that does not forward Vite HMR websocket connections.
- The Gemini video-generation deprecation warning is separate and does not cause this websocket failure.

## Changes made
1. `vite.config.ts`: replaced `__dirname` with `import.meta.dirname`.
2. When `DISABLE_HMR=true`, Vite HMR is explicitly disabled and file watching is disabled.
3. `package.json`: `npm run dev` sets `DISABLE_HMR=true` for the cloud preview.

## Verify in AI Studio
1. Upload/apply this repaired ZIP.
2. Stop the existing server and restart with `npm run dev`.
3. Confirm `[vite] failed to connect to websocket` is gone.
4. Check `GET /api/health` returns `status: online`.
5. Test basic frontend navigation.

## Scope
This repair targets the Vite HMR websocket failure only. It does not yet prove Gemini video generation, duration accuracy, timeline assembly, or MP4 export.
