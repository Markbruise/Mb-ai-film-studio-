<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# M-b AI Film Studio — Google AI Studio Web App

Professional AI filmmaking studio with automatic screenplay breakdown, multi-provider clip duration calibration, intelligent script supervisor continuity auditing, and multi-track timeline assembly.

## Running in Google AI Studio

1. **Importing into Google AI Studio**:
   - Upload or drag-and-drop this project ZIP into Google AI Studio.
   - AI Studio automatically loads `metadata.json` and injects `GEMINI_API_KEY` and `APP_URL` into the environment.
2. **Configure API Secrets**:
   - In Google AI Studio, ensure your Gemini API Key is enabled under Secrets.
   - The server uses `gemini-2.5-flash` for fast, structured screenplay breakdown, continuity audits, and director advice.

## Running Locally

**Prerequisites:** Node.js (v18+)

1. Install dependencies:
   ```bash
   npm install
   ```
2. Configure environment:
   - Copy `.env.example` to `.env` (or `.env.local`):
     ```bash
     cp .env.example .env
     ```
   - Add your Gemini API key in `GEMINI_API_KEY`.
3. Start the development server:
   ```bash
   npm run dev
   ```
4. Production build and run:
   ```bash
   npm run build
   npm start
   ```

## Architecture & Features

- **Screenplay Breakdown Studio**: Accepts screenplay text (4 seconds to 120 minutes) and divides it into Acts, Scenes, and Shots with precise duration budgeting.
- **Provider Limit Sub-Division**: Automatically divides long shots into seamless sub-clips respecting provider constraints (Google Veo 2: 8s, OpenAI Sora: 20s, Runway Gen-3: 10s, Luma Dream Machine: 5s, Kling AI: 10s, Pika: 4s).
- **Interactive Multi-Track Timeline**: Visual track editor supporting drag-and-drop reordering, duration trimming, SMPTE timecodes (`HH:MM:SS:FF`), and automated time-alignment to target film duration.
- **Cinema Canvas Player**: Real-time 24 FPS procedural cinema player with simulated camera motion (Push In/Dolly, Pan, Tilt, Orbital Crane), letterbox aspect ratios (2.39:1, 16:9, 9:16), rule-of-thirds grid, and dialogue subtitle displays.
- **AI Continuity Assistant**: Hollywood Script Supervisor auditing for 180-degree axis flips, lighting and time-of-day jumps, camera jump cuts, and prompt vector alignment.
- **Export & NLE Render Center**: Generates CMX 3600 EDL (Edit Decision List), FCPXML 1.9 (Final Cut Pro / DaVinci Resolve), Subtitle SRT, and downloadable production package manifest.
