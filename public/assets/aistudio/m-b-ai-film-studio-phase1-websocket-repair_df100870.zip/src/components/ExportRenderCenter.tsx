import React, { useState } from 'react';
import { FilmProject, RenderExportSettings } from '../types/film';
import { formatDurationNice, formatSMPTETimecode } from '../utils/timecode';
import {
  Download,
  Film,
  Sliders,
  Settings2,
  Terminal,
  FileCode,
  CheckCircle2,
  Volume2,
  Monitor,
  Sparkles,
  Zap,
} from 'lucide-react';

interface ExportRenderCenterProps {
  project: FilmProject;
  onUpdateExportSettings: (settings: RenderExportSettings) => void;
  onNavigateToPreview: () => void;
}

export const ExportRenderCenter: React.FC<ExportRenderCenterProps> = ({
  project,
  onUpdateExportSettings,
  onNavigateToPreview,
}) => {
  const [settings, setSettings] = useState<RenderExportSettings>(project.exportSettings);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportProgress, setExportProgress] = useState<number>(0);
  const [exportStage, setExportStage] = useState<string>('');
  const [exportResult, setExportResult] = useState<any | null>(null);

  const handleExport = async () => {
    setIsExporting(true);
    setExportProgress(10);
    setExportStage('Analyzing assembled clips and audio tracks...');

    try {
      // Step 1: Pre-process
      await new Promise((r) => setTimeout(r, 600));
      setExportProgress(35);
      setExportStage('Applying Color Grade LUT & audio channel mixing...');

      // Step 2: Call Server /api/render
      const response = await fetch('/api/render', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ project, settings }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Export metadata request failed');

      setExportProgress(100);
      setExportStage('Editing metadata package prepared (no MP4 rendered).');
      setExportResult(data);
    } catch (err) {
      console.error('Export error:', err);
      // Do not fabricate a successful export when the server is unavailable.
      setExportResult({
        status: 'error',
        error: err instanceof Error ? err.message : 'Server export endpoint unavailable.',
        filmTitle: project.title,
        assembledDuration: project.actualAssembledDuration,
        clipsCount: project.clips.length,
        resolution: settings.resolution,
        aspectRatio: settings.aspectRatio,
        message: 'No MP4 or export package was created. Please start the server and retry.',
      });
    } finally {
      setIsExporting(false);
    }
  };

  const downloadFile = (filename: string, content: string, mime = 'text/plain') => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-zinc-950 rounded-xl border border-zinc-800 shadow-2xl p-6 text-zinc-100 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-zinc-800 gap-4">
        <div>
          <div className="flex items-center space-x-2 text-xs font-semibold text-cyan-400 uppercase tracking-widest mb-1">
            <Film className="w-4 h-4" />
            <span>Step 5: Master Rendering & Export Pipeline</span>
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-white">
            Video Rendering & Assembly Export
          </h2>
          <p className="text-sm text-zinc-400 mt-1 max-w-2xl">
            Prepares editing metadata (EDL, FCPXML, SRT, and manifest). Actual MP4 rendering requires a configured video-rendering worker.
          </p>
        </div>

        <button
          onClick={handleExport}
          disabled={isExporting}
          className="flex items-center space-x-2 px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-600 via-indigo-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white font-semibold text-sm shadow-xl shadow-indigo-950/40 transition active:scale-95 disabled:opacity-50 shrink-0"
        >
          {isExporting ? (
            <>
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span>Rendering Film Master...</span>
            </>
          ) : (
            <>
              <Download className="w-4 h-4" />
              <span>Render & Export Final Film</span>
            </>
          )}
        </button>
      </div>

      {/* Export Progress Bar if exporting or completed */}
      {(isExporting || exportResult) && (
        <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-zinc-200">{exportStage}</span>
            <span className="font-mono text-cyan-400 font-bold">{exportProgress}%</span>
          </div>
          <div className="w-full bg-zinc-800 rounded-full h-2.5 overflow-hidden">
            <div
              className="bg-gradient-to-r from-cyan-500 via-indigo-500 to-emerald-400 h-2.5 rounded-full transition-all duration-300"
              style={{ width: `${exportProgress}%` }}
            />
          </div>
        </div>
      )}

      {/* Render Settings Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Panel 1: Video Encoding & Format */}
        <div className="bg-zinc-900/60 p-5 rounded-xl border border-zinc-800/80 space-y-4">
          <div className="flex items-center space-x-2 text-sm font-semibold text-white">
            <Monitor className="w-4 h-4 text-cyan-400" />
            <span>Format & Resolution</span>
          </div>

          <div>
            <label className="text-xs text-zinc-400 block mb-1">Target Resolution</label>
            <select
              value={settings.resolution}
              onChange={(e) => {
                const updated = { ...settings, resolution: e.target.value as any };
                setSettings(updated);
                onUpdateExportSettings(updated);
              }}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2.5 text-xs text-white"
            >
              <option value="1080p">1080p Full HD (1920 × 1080)</option>
              <option value="4K Cinema">4K Cinema Master (3840 × 2160)</option>
              <option value="720p">720p HD (1280 × 720)</option>
            </select>
          </div>

          <div>
            <label className="text-xs text-zinc-400 block mb-1">Aspect Ratio</label>
            <select
              value={settings.aspectRatio}
              onChange={(e) => {
                const updated = { ...settings, aspectRatio: e.target.value as any };
                setSettings(updated);
                onUpdateExportSettings(updated);
              }}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2.5 text-xs text-white"
            >
              <option value="2.39:1">2.39:1 Anamorphic Cinemascope</option>
              <option value="16:9">16:9 Widescreen Standard</option>
              <option value="9:16">9:16 Vertical Reel / Mobile</option>
              <option value="4:3">4:3 Vintage Academy</option>
            </select>
          </div>

          <div>
            <label className="text-xs text-zinc-400 block mb-1">Master Codec</label>
            <select
              value={settings.codec}
              onChange={(e) => {
                const updated = { ...settings, codec: e.target.value as any };
                setSettings(updated);
                onUpdateExportSettings(updated);
              }}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2.5 text-xs text-white"
            >
              <option value="H.264">H.264 / AVC (Broad Compatibility)</option>
              <option value="ProRes 422">Apple ProRes 422 HQ (Mastering)</option>
              <option value="HEVC">HEVC / H.265 (High Compression)</option>
              <option value="VP9 / WebM">VP9 / WebM (Streaming Web)</option>
            </select>
          </div>
        </div>

        {/* Panel 2: Color Grade & Look LUT */}
        <div className="bg-zinc-900/60 p-5 rounded-xl border border-zinc-800/80 space-y-4">
          <div className="flex items-center space-x-2 text-sm font-semibold text-white">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span>Color Grading LUT</span>
          </div>

          <div>
            <label className="text-xs text-zinc-400 block mb-1">Cinema Look Profile</label>
            <select
              value={settings.colorGradeLUT}
              onChange={(e) => {
                const updated = { ...settings, colorGradeLUT: e.target.value as any };
                setSettings(updated);
                onUpdateExportSettings(updated);
              }}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg p-2.5 text-xs text-white"
            >
              <option value="Cinematic Teal & Orange">Cinematic Teal & Orange (Hollywood Standard)</option>
              <option value="Sci-Fi Cyberpunk">Sci-Fi Cyberpunk (Vibrant Neon & Cobalt)</option>
              <option value="Noir High-Contrast">Noir High-Contrast (Deep Shadows & Speculars)</option>
              <option value="Kodak 5219 Warm">Kodak 5219 Warm (Analog 35mm Grain & Halation)</option>
              <option value="Clean Rec709">Clean Rec709 Neutral</option>
            </select>
          </div>

          <div className="pt-2">
            <label className="flex items-center space-x-2 text-xs text-zinc-300 cursor-pointer">
              <input
                type="checkbox"
                checked={settings.burnSubtitles}
                onChange={(e) => {
                  const updated = { ...settings, burnSubtitles: e.target.checked };
                  setSettings(updated);
                  onUpdateExportSettings(updated);
                }}
                className="w-4 h-4 rounded bg-zinc-950 border-zinc-700 text-cyan-500 focus:ring-0"
              />
              <span>Burn-In Dialogue Subtitles (SRT/VTT)</span>
            </label>
            <p className="text-[11px] text-zinc-500 mt-1 pl-6">
              Renders yellow typography in lower third with anti-aliased backdrop pill.
            </p>
          </div>
        </div>

        {/* Panel 3: Audio Channel Mixing */}
        <div className="bg-zinc-900/60 p-5 rounded-xl border border-zinc-800/80 space-y-4">
          <div className="flex items-center space-x-2 text-sm font-semibold text-white">
            <Volume2 className="w-4 h-4 text-amber-400" />
            <span>Multi-Track Audio Mixing</span>
          </div>

          <div>
            <div className="flex justify-between text-xs text-zinc-400 mb-1">
              <span>Dialogue Channel</span>
              <span className="font-mono text-cyan-400">{settings.audioMix.dialogueLevel}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={settings.audioMix.dialogueLevel}
              onChange={(e) => {
                const updated = {
                  ...settings,
                  audioMix: { ...settings.audioMix, dialogueLevel: parseInt(e.target.value, 10) },
                };
                setSettings(updated);
                onUpdateExportSettings(updated);
              }}
              className="w-full accent-cyan-500"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs text-zinc-400 mb-1">
              <span>Music Score Channel</span>
              <span className="font-mono text-purple-400">{settings.audioMix.musicLevel}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={settings.audioMix.musicLevel}
              onChange={(e) => {
                const updated = {
                  ...settings,
                  audioMix: { ...settings.audioMix, musicLevel: parseInt(e.target.value, 10) },
                };
                setSettings(updated);
                onUpdateExportSettings(updated);
              }}
              className="w-full accent-purple-500"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs text-zinc-400 mb-1">
              <span>Sound Effects Foley (SFX)</span>
              <span className="font-mono text-emerald-400">{settings.audioMix.sfxLevel}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={settings.audioMix.sfxLevel}
              onChange={(e) => {
                const updated = {
                  ...settings,
                  audioMix: { ...settings.audioMix, sfxLevel: parseInt(e.target.value, 10) },
                };
                setSettings(updated);
                onUpdateExportSettings(updated);
              }}
              className="w-full accent-emerald-500"
            />
          </div>
        </div>
      </div>

      {exportResult?.status === 'error' && (
        <div className="p-4 rounded-xl border border-red-900 bg-red-950/40 text-sm text-red-200">
          <strong>Export failed:</strong> {exportResult.error || exportResult.message || 'No export was created.'}
        </div>
      )}

      {/* Export Downloads & Artifacts when ready */}
      {exportResult && exportResult.status !== 'error' && (
        <div className="p-6 bg-zinc-900 border border-zinc-700/80 rounded-xl space-y-4 shadow-xl">
          <div className="flex items-center space-x-2 text-amber-400 text-sm font-bold">
            <CheckCircle2 className="w-5 h-5" />
            <span>Editing Metadata Ready (Not an MP4 Film)</span>
          </div>
          {exportResult.message && <p className="text-xs text-zinc-400">{exportResult.message}</p>}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
            {/* Download 1: Master Video EDL */}
            <button
              onClick={() =>
                downloadFile(
                  `${project.title.toLowerCase().replace(/\s+/g, '_')}_master.edl`,
                  exportResult.edl || 'TITLE: MASTER'
                )
              }
              className="p-3 rounded-lg bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-left transition flex items-center justify-between"
            >
              <div>
                <div className="text-xs font-bold text-white">CMX 3600 EDL</div>
                <div className="text-[10px] text-zinc-500">For DaVinci Resolve & Premiere</div>
              </div>
              <Download className="w-4 h-4 text-cyan-400" />
            </button>

            {/* Download 2: Final Cut Pro XML */}
            <button
              onClick={() =>
                downloadFile(
                  `${project.title.toLowerCase().replace(/\s+/g, '_')}_master.fcpxml`,
                  exportResult.fcpxml || '<fcpxml></fcpxml>',
                  'application/xml'
                )
              }
              className="p-3 rounded-lg bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-left transition flex items-center justify-between"
            >
              <div>
                <div className="text-xs font-bold text-white">Final Cut Pro XML</div>
                <div className="text-[10px] text-zinc-500">Timeline sequences with tracks</div>
              </div>
              <Download className="w-4 h-4 text-indigo-400" />
            </button>

            {/* Download 3: Subtitles SRT */}
            <button
              onClick={() =>
                downloadFile(
                  `${project.title.toLowerCase().replace(/\s+/g, '_')}_subtitles.srt`,
                  exportResult.srt || '1\n00:00:00,000 --> 00:00:02,000\n[Speech]'
                )
              }
              className="p-3 rounded-lg bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-left transition flex items-center justify-between"
            >
              <div>
                <div className="text-xs font-bold text-white">SRT Subtitles</div>
                <div className="text-[10px] text-zinc-500">Synced dialogue timecodes</div>
              </div>
              <Download className="w-4 h-4 text-amber-400" />
            </button>

            {/* Download 4: Full Assembly Manifest JSON */}
            <button
              onClick={() =>
                downloadFile(
                  `${project.title.toLowerCase().replace(/\s+/g, '_')}_manifest.json`,
                  JSON.stringify(exportResult, null, 2),
                  'application/json'
                )
              }
              className="p-3 rounded-lg bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-left transition flex items-center justify-between"
            >
              <div>
                <div className="text-xs font-bold text-white">Film Manifest (JSON)</div>
                <div className="text-[10px] text-zinc-500">Complete multi-track schema</div>
              </div>
              <Download className="w-4 h-4 text-purple-400" />
            </button>
          </div>

          {/* Infrastructure & FFmpeg Concatenation Script Instructions */}
          <div className="mt-4 pt-4 border-t border-zinc-800 space-y-2">
            <div className="flex items-center space-x-2 text-xs font-semibold text-zinc-400">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <span>FFmpeg Production Server Concatenation Specification</span>
            </div>
            <pre className="bg-zinc-950 p-3 rounded-lg border border-zinc-800 text-[11px] font-mono text-zinc-300 overflow-x-auto leading-relaxed">
{`# M-b Film Studio Cloud Concatenation Command
# Input: ${project.clips.length} generated provider clips | Resolution: ${settings.resolution} | Aspect: ${settings.aspectRatio}
ffmpeg -f concat -safe 0 -i clips_manifest.txt \\
  -i master_score.wav -i master_dialogue.wav \\
  -filter_complex "[0:v]scale=1920:1080,lut3d='${settings.colorGradeLUT}.cube'[v];[1:a][2:a]amix=inputs=2[a]" \\
  -map "[v]" -map "[a]" -c:v libx264 -preset slow -crf 18 -c:a aac -b:a 320k \\
  ${project.title.toLowerCase().replace(/\s+/g, '_')}_master_${settings.resolution}.mp4`}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};
