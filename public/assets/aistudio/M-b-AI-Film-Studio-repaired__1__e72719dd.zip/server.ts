import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '15mb' }));

// Lightweight per-IP rate limiter. For multi-instance production deployments,
// replace this in-memory limiter with a shared Redis/API gateway limiter.
const rateBuckets = new Map<string, { count: number; resetAt: number }>();
const rateLimit = (maxRequests = 30, windowMs = 60_000) => (req: Request, res: Response, next: any) => {
  const key = req.ip || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  let bucket = rateBuckets.get(key);
  if (!bucket || bucket.resetAt <= now) bucket = { count: 0, resetAt: now + windowMs };
  bucket.count += 1;
  rateBuckets.set(key, bucket);
  if (bucket.count > maxRequests) return res.status(429).json({ error: 'Rate limit exceeded. Please try again later.' });
  next();
};
app.use('/api/ai', rateLimit(20));
app.use('/api/jobs', rateLimit(60));
app.use('/api/render', rateLimit(10));

// Gemini model: use standard current fast model gemini-2.5-flash with env fallback
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';

// Initialize Google GenAI client (Server-side only)
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI | null {
  const key = process.env.GEMINI_API_KEY;
  if (!key || key.trim() === '' || key === 'MY_GEMINI_API_KEY') {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Safely parse JSON from Gemini responses (handles optional markdown code blocks)
function parseGeminiJson<T = any>(rawText: string | undefined): T {
  if (!rawText) return {} as T;
  const cleaned = rawText
    .trim()
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```$/i, '')
    .trim();
  return JSON.parse(cleaned);
}

// In-memory Job Queue storage for asynchronous multi-clip generation and rendering
interface ServerJob {
  jobId: string;
  filmProjectId: string;
  type: string;
  targetId: string;
  title: string;
  status: 'queued' | 'processing' | 'completed' | 'failed';
  progress: number;
  createdAt: number;
  completedAt?: number;
  error?: string;
  retryCount: number;
}

const serverJobQueue: Map<string, ServerJob> = new Map();

// API Routes

/**
 * AI Screenplay & Film Breakdown API
 * Takes screenplay text + target duration and returns structural analysis
 */
app.post('/api/ai/breakdown', async (req: Request, res: Response) => {
  try {
    const { screenplay, targetDurationSeconds, genre, title, provider } = req.body;

    if (typeof screenplay !== 'string' || !screenplay.trim()) {
      return res.status(400).json({ error: 'Screenplay text is required' });
    }
    if (screenplay.length > 100_000) {
      return res.status(413).json({ error: 'Screenplay exceeds the 100,000 character limit.' });
    }
    if (!Number.isFinite(targetDurationSeconds) || targetDurationSeconds < 4 || targetDurationSeconds > 7200) {
      return res.status(400).json({ error: 'targetDurationSeconds must be between 4 and 7200 seconds.' });
    }

    const ai = getAI();
    if (!ai) {
      // Fallback: indicate that client engine can use algorithmic breakdown
      return res.json({
        source: 'algorithmic_fallback',
        message: 'No GEMINI_API_KEY configured; utilizing built-in cinema breakdown engine.',
      });
    }

    const prompt = `You are a legendary Hollywood cinema director and Master Film Editor.
Analyze the following screenplay and plan a cinematic film breakdown strictly targeting ${targetDurationSeconds} seconds total film duration.

Target Film Duration: ${targetDurationSeconds} seconds.
Selected Video Provider: ${provider || 'Google Veo 2'}.
Genre: ${genre || 'Cinematic Drama'}.
Title: ${title || 'Untitled'}.

Screenplay Content:
${screenplay.slice(0, 8000)}

Requirements:
1. Divide the story into 1-3 Acts.
2. Divide Acts into Scenes with precise target durations in seconds (sum of scenes must equal approx ${targetDurationSeconds}s).
3. Divide each Scene into distinct Shots (Wide Establishing, Medium Shot, Close-Up, Tracking Dolly, Aerial Drone, POV, etc.).
4. Calculate duration for every shot in seconds.
5. Provide camera movement, angle, mood, and visual continuity tags (screenDirection, lightingKey, colorPalette, location, timeOfDay).
6. Return structured JSON matching the schema.`;

    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            logline: { type: Type.STRING },
            genre: { type: Type.STRING },
            targetDurationSeconds: { type: Type.NUMBER },
            acts: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  actNumber: { type: Type.INTEGER },
                  title: { type: Type.STRING },
                  summary: { type: Type.STRING },
                  targetDuration: { type: Type.NUMBER },
                },
              },
            },
            scenes: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  sceneNumber: { type: Type.INTEGER },
                  heading: { type: Type.STRING },
                  location: { type: Type.STRING },
                  timeOfDay: { type: Type.STRING },
                  mood: { type: Type.STRING },
                  targetDuration: { type: Type.NUMBER },
                  shots: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        shotNumber: { type: Type.INTEGER },
                        shotType: { type: Type.STRING },
                        cameraMovement: { type: Type.STRING },
                        angle: { type: Type.STRING },
                        description: { type: Type.STRING },
                        duration: { type: Type.NUMBER },
                        screenDirection: { type: Type.STRING },
                        lightingKey: { type: Type.STRING },
                        colorPalette: { type: Type.STRING },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    });

    const parsedJson = parseGeminiJson(response.text);
    return res.json({
      source: 'gemini',
      data: parsedJson,
    });
  } catch (error: any) {
    console.error('Gemini breakdown error:', error);
    return res.status(500).json({
      error: error?.message || 'Failed to process AI breakdown',
      source: 'error',
    });
  }
});

/**
 * AI Continuity Assistant Endpoint
 * Validates continuity between shots
 */
app.post('/api/ai/continuity-audit', async (req: Request, res: Response) => {
  try {
    const { shots } = req.body;

    if (!shots || !Array.isArray(shots) || shots.length === 0) {
      return res.status(400).json({ error: 'Shots array required' });
    }

    const ai = getAI();
    if (!ai) {
      return res.json({ source: 'client_fallback' });
    }

    const summaryShots = shots.map((s: any) => ({
      shotNumber: s.shotNumber,
      shotType: s.shotType,
      camera: s.cameraMovement,
      direction: s.visualContinuity?.screenDirection,
      lighting: s.visualContinuity?.lightingKey,
      timeOfDay: s.visualContinuity?.timeOfDay,
      desc: s.description,
    }));

    const prompt = `You are an elite Hollywood Script Supervisor and Continuity Director.
Analyze this sequence of shots for visual and temporal continuity:
${JSON.stringify(summaryShots, null, 2)}

Audit for:
1. 180-degree rule / Screen direction flips (e.g. left-to-right suddenly reversing without cutaway).
2. Time-of-day / lighting consistency jumps within same location.
3. Prop and costume continuity errors.
4. Jump cuts (consecutive similar static framings).

Provide a list of issues with severity ('high', 'medium', 'low') and concrete recommended director fixes.`;

    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            overallContinuityScore: { type: Type.INTEGER },
            executiveSummary: { type: Type.STRING },
            issues: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  shotNumberA: { type: Type.INTEGER },
                  shotNumberB: { type: Type.INTEGER },
                  issueType: { type: Type.STRING },
                  severity: { type: Type.STRING },
                  description: { type: Type.STRING },
                  recommendation: { type: Type.STRING },
                },
              },
            },
          },
        },
      },
    });

    const parsed = parseGeminiJson(response.text);
    return res.json({ source: 'gemini', data: parsed });
  } catch (error: any) {
    console.error('Continuity audit error:', error);
    return res.status(500).json({ error: error?.message || 'Continuity audit failed' });
  }
});

/**
 * AI Director Advice & Duration Balancing Endpoint
 */
app.post('/api/ai/director-advice', async (req: Request, res: Response) => {
  try {
    const { targetDuration, assembledDuration, scenesCount, shotsCount, genre } = req.body;

    const ai = getAI();
    if (!ai) {
      return res.json({
        advice: `Timeline is ${Math.abs(targetDuration - assembledDuration).toFixed(1)}s ${assembledDuration < targetDuration ? 'under' : 'over'} target. Consider pacing adjustments.`,
      });
    }

    const delta = Math.round((assembledDuration - targetDuration) * 10) / 10;

    const prompt = `You are a veteran Film Director and Head of Post-Production.
The project currently has:
- Target Film Duration: ${targetDuration} seconds
- Assembled Timeline Duration: ${assembledDuration} seconds
- Variance (Delta): ${delta} seconds (${delta > 0 ? 'over' : delta < 0 ? 'under' : 'perfect'})
- Scenes: ${scenesCount}
- Shots: ${shotsCount}
- Genre: ${genre}

Advise the user on how to bring the timeline to the target duration without sacrificing narrative stakes or provider clip limits.
Give 3 bullet points with specific shot timing recommendations.`;

    const response = await ai.models.generateContent({
      model: GEMINI_MODEL,
      contents: prompt,
    });

    return res.json({ advice: response.text });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

/**
 * Job Queue Endpoints
 */
app.get('/api/jobs', (_req: Request, res: Response) => {
  res.json(Array.from(serverJobQueue.values()));
});

app.post('/api/jobs/create', (req: Request, res: Response) => {
  const { jobId, filmProjectId, type, targetId, title } = req.body || {};
  if (typeof filmProjectId !== 'string' || !filmProjectId.trim()) {
    return res.status(400).json({ error: 'filmProjectId is required.' });
  }
  const newJob: ServerJob = {
    jobId: jobId || `job_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    filmProjectId,
    type: type || 'generate_clip',
    targetId: targetId || '',
    title: title || 'Asynchronous Job',
    status: 'queued',
    progress: 0,
    createdAt: Date.now(),
    retryCount: 0,
    error: 'Queued only: connect a real generation worker/provider adapter to process this job.',
  };
  serverJobQueue.set(newJob.jobId, newJob);
  res.status(201).json(newJob);
});

app.post('/api/jobs/:id/retry', (req: Request, res: Response) => {
  const { id } = req.params;
  const job = serverJobQueue.get(id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  job.status = 'queued';
  job.progress = 0;
  job.retryCount += 1;
  job.error = 'Retry queued; a real generation worker/provider adapter is required to execute it.';
  delete job.completedAt;
  res.json(job);
});

/**
 * Video Rendering & Assembly Export Endpoint
 * Returns full EDL, FCPXML, Subtitle SRT, and downloadable Film Package manifest
 */
app.post('/api/render', (req: Request, res: Response) => {
  const { project, settings } = req.body;
  if (!project) {
    return res.status(400).json({ error: 'Project data required' });
  }

  if (!Array.isArray(project.clips)) {
    return res.status(400).json({ error: 'project.clips must be an array.' });
  }
  const clips = project.clips;
  if (clips.length > 5000) return res.status(413).json({ error: 'Too many clips for one export package.' });
  const fps = Number.isFinite(project.fps) && project.fps > 0 ? project.fps : 24;
  if (clips.some((clip: any) => !Number.isFinite(clip.duration) || clip.duration <= 0)) {
    return res.status(400).json({ error: 'Every clip must have a positive numeric duration.' });
  }

  // Generate Edit Decision List (EDL CMX 3600)
  let edlContent = `TITLE: ${project.title.toUpperCase()}\nFCM: NON-DROP FRAME\n\n`;
  clips.forEach((clip: any, idx: number) => {
    const editNum = String(idx + 1).padStart(3, '0');
    const reel = `AX`;
    edlContent += `${editNum}  ${reel}       V     C        00:00:00:00 ${clip.timecode || '00:00:00:00'} ${clip.timecode || '00:00:00:00'} ${clip.timecode || '00:00:00:00'}\n`;
    edlContent += `* FROM CLIP NAME: ${clip.clipId}.mp4\n`;
    edlContent += `* PROMPT: ${clip.prompt?.slice(0, 80)}...\n\n`;
  });

  // Generate Subtitles (SRT)
  let srtContent = '';
  const dialogues = project.dialogueTracks || [];
  dialogues.forEach((dlg: any, idx: number) => {
    const startSec = dlg.startTime;
    const endSec = dlg.startTime + dlg.duration;
    const formatSrtTime = (s: number) => {
      const h = Math.floor(s / 3600);
      const m = Math.floor((s % 3600) / 60);
      const sec = Math.floor(s % 60);
      const ms = Math.floor((s % 1) * 1000);
      const p = (n: number, z = 2) => String(n).padStart(z, '0');
      return `${p(h)}:${p(m)}:${p(sec)},${String(ms).padStart(3, '0')}`;
    };
    srtContent += `${idx + 1}\n${formatSrtTime(startSec)} --> ${formatSrtTime(endSec)}\n${dlg.character}: ${dlg.text}\n\n`;
  });

  // Final Cut Pro XML (FCPXML 1.9)
  const fcpxml = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE fcpxml>
<fcpxml version="1.9">
  <resources>
    <format id="r1" name="FFVideoFormat${settings?.resolution || '1080p'}" frameDuration="100/${fps * 100}s" width="1920" height="1080"/>
  </resources>
  <library>
    <event name="${project.title}">
      <project name="${project.title} - Master">
        <sequence format="r1" duration="${Math.round(project.actualAssembledDuration * fps)}/${fps}s">
          <spine>
            ${clips
              .map(
                (c: any) =>
                  `<clip name="${c.clipId}" duration="${Math.round(c.duration * fps)}/${fps}s" start="0s"/>`
              )
              .join('\n            ')}
          </spine>
        </sequence>
      </project>
    </event>
  </library>
</fcpxml>`;

  res.json({
    status: 'package_ready',
    message: 'This endpoint creates editing metadata only (EDL, SRT, FCPXML, manifest). It does not render or encode an MP4. Add a real FFmpeg/render worker for final video output.',
    renderJobId: `render_${Date.now()}`,
    filmTitle: project.title,
    assembledDuration: project.actualAssembledDuration,
    clipsCount: clips.length,
    resolution: settings?.resolution || '1080p',
    aspectRatio: settings?.aspectRatio || '2.39:1',
    edl: edlContent,
    srt: srtContent,
    fcpxml,
    manifest: {
      generatedAt: new Date().toISOString(),
      sourceProject: project.id,
      tracks: {
        video: clips.length,
        dialogue: dialogues.length,
        sfx: project.sfxTracks?.length || 0,
        music: project.musicTracks?.length || 0,
      },
      exportSettings: settings,
    },
  });
});

// Vite middleware in dev or static files in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // In production, when running from dist/server.js:
    // check if index.html is located in __dirname (meaning we are inside dist)
    // or in path.resolve(__dirname, 'dist') (meaning server is run from project root)
    const distPath = fs.existsSync(path.resolve(__dirname, 'index.html'))
      ? __dirname
      : path.resolve(__dirname, 'dist');

    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[M-b AI Film Studio] Server running on http://0.0.0.0:${PORT} (Gemini Model: ${GEMINI_MODEL})`);
  });
}

startServer();
