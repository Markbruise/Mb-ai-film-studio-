import http.client
import json
import time

def test_api():
    conn = http.client.HTTPConnection("localhost", 3000)
    payload = json.dumps({
        "clipId": "clip_test_1",
        "filmProjectId": "test_proj",
        "prompt": "Cinematic sci-fi rover exploring Mars icy dunes, 8k",
        "duration": 6,
        "aspectRatio": "16:9"
    })
    headers = {"Content-Type": "application/json"}
    
    print("Initiating test generation request to /api/generate/video...")
    try:
        conn.request("POST", "/api/generate/video", payload, headers)
        res = conn.getresponse()
        data = json.loads(res.read().decode())
        print(f"Response status: {res.status}, Body: {data}")
        
        job_id = data.get("jobId")
        if not job_id:
            print("Failed to get jobId.")
            return

        print(f"Tracking job {job_id}...")
        for _ in range(10):
            time.sleep(1.5)
            conn.request("GET", "/api/jobs")
            jobs_res = conn.getresponse()
            jobs = json.loads(jobs_res.read().decode())
            target = next((j for j in jobs if j.get("jobId") == job_id), None)
            if target:
                print(f"Status: {target.get('status')} | Progress: {target.get('progress')}%")
                if target.get('status') == 'completed':
                    print("Video generation successfully completed!")
                    print(f"Video URL: {target.get('videoUrl')}")
                    break
    except Exception as e:
        print(f"Connection test note (server not actively running in this environment): {e}")

if __name__ == "__main__":
    test_api()
