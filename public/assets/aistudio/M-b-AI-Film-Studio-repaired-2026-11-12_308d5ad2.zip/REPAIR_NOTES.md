# M-b AI Film Studio — ZIP Audit & Repair Notes (12 November 2026)

## Repairs made in this package

1. **Production storage path corrected (`server.ts`)**
   - The production server is bundled to `dist/server.js`. Media and job paths previously resolved relative to `dist/`, which could create a second `dist/public` and `dist/data` tree instead of using the project assets.
   - Added a project-root resolver so uploads, exports, audio and job persistence consistently use the root `public/` and `data/` directories in both development and production.

2. **Video provider availability made honest (`ScreenplayStudio.tsx`, `server.ts`)**
   - Gemini Omni Flash is the only connected video provider in this package. Other provider cards are now visibly disabled as “Not connected” instead of appearing ready and then silently being sent through the Gemini Omni route.
   - Removed the misleading Vertex branch: it constructed the client with a Gemini Developer API key but attempted a Vertex AI operation, which is not a valid Vertex authentication setup.
   - The server now rejects unsupported provider IDs with a clear error and never creates a fake successful video.

3. **Gemini video request and asset checks hardened (`server.ts`)**
   - Uses the configurable `GEMINI_VIDEO_MODEL` (default `gemini-omni-1.2-flash`) through the documented Gemini Interactions API.
   - Validates reference image data, constrains requested duration to the model's 3–15 second range, downloads returned URI assets using authenticated `fetch`, and verifies the MP4 `ftyp` signature plus a real video stream with `ffprobe` before marking a job complete.
   - The API model itself is not the confirmed blocker in the archived job history: the stored failure explicitly reports HTTP 429 / Free Tier quota of 0 for video generation. A paid API tier and enabled billing/quota are required.

4. **Upload validation improved (`server.ts`)**
   - Uploads that are not genuine MP4 containers are rejected with HTTP 400.
   - `ffprobe` must confirm a real video stream and positive duration before the upload is accepted. Invalid files are removed.

5. **MP4 render pipeline hardened (`server.ts`)**
   - FFmpeg and ffprobe are invoked with argument arrays rather than shell-interpolated file paths for the main clip normalization, concatenation, final encode, validation and TTS paths.
   - Remote clip downloads use `fetch` rather than shelling out to `curl`.
   - Local media URLs are resolved inside the public asset directory, preventing path traversal outside the app's media folder.
   - The MP4 download route continues to serve `video/mp4` with an attachment filename and byte-range support.

6. **Preview-only motion plates separated from final footage**
   - FFmpeg-generated title/motion plates are explicitly labelled `previewOnly` and the MP4 master renderer rejects them. They are not real AI-generated scenes or realistic human footage.
   - The motion-plate command now uses argument-based FFmpeg invocation.

7. **Retry text and verification scripts corrected**
   - Removed a misleading frontend retry status message.
   - Python verification scripts now use the project `public/` directory by default and allow `PUBLIC_DIR` / `BASE_URL` overrides instead of relying on `/app/applet`.
   - Added `verify_media_assets.py`; the render integration fixtures now upload short test MP4s instead of using preview-only title plates.
   - Removed one archived corrupt MP4 export (`moov atom not found`), cleared stale demo job records, and removed old nested ZIP backups from the public static folder.

## Verification performed

- Python test/verification scripts: **syntax check passed** (`python -m py_compile`).
- FFmpeg media pipeline: **passed** using two existing genuine MP4 clips; normalized, concatenated, encoded an MP4 with H.264 video and AAC stereo audio; `ffprobe` read the result and the `ftyp` signature was present. The temporary test render was removed.
- Existing media inventory: 19 of 20 archived MP4 assets initially probed successfully; the single corrupt export was removed.
- TypeScript/Vite build: **not completed in this environment**. The ZIP has no `package-lock.json` and no `node_modules`; `npm install` timed out while attempting dependency retrieval. Global `tsc` cannot type-check the project without the declared Vite/React/Node type packages. Do not treat the project as build-certified until `npm install`, `npm run lint`, and `npm run build` pass in the target environment.
- Live Gemini video generation: **not executed** because this audit environment has no user API key and no paid video quota. The archived `data/jobs.json` did contain a real provider error: `429 Rate limit exceeded ... limit: 0 ... Free Tier`.

## Required setup before real AI video generation

1. In Google AI Studio, create/use a Gemini API key and configure it in the app's Secrets as `GEMINI_API_KEY`.
2. Ensure the API project has billing enabled and paid-tier access/quota for Gemini Omni video generation. A Gemini Advanced/Pro consumer subscription does not automatically provide Gemini API billing or video quota.
3. Optionally set `GEMINI_VIDEO_MODEL=gemini-omni-1.2-flash`; this is the default.
4. Rebuild and run the app, then test one short clip (3–6 seconds) before queuing a full film.

## Important capability boundary

The 4-second to 120-minute film length is a **timeline project duration**, not a single AI video-generation request. Gemini Omni generates short clips (3–15 seconds per request); M-b must generate many clips and join them through the FFmpeg timeline export pipeline. Generation costs, provider quota, and time increase with the number of clips.
