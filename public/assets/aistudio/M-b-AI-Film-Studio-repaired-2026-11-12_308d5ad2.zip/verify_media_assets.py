#!/usr/bin/env python3
"""Check every bundled MP4 for a valid MP4 container and readable video stream."""
import json
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
PUBLIC_DIR = os.environ.get("PUBLIC_DIR", os.path.join(ROOT, "public"))


def main():
    files = []
    for folder in ("uploads", "exports"):
        directory = os.path.join(PUBLIC_DIR, folder)
        if os.path.isdir(directory):
            files.extend(os.path.join(directory, name) for name in os.listdir(directory) if name.lower().endswith(".mp4"))

    failures = []
    for filename in sorted(files):
        try:
            with open(filename, "rb") as handle:
                if b"ftyp" not in handle.read(32):
                    raise ValueError("missing MP4 ftyp signature")
            raw = subprocess.check_output([
                "ffprobe", "-v", "error", "-show_format", "-show_streams", "-of", "json", filename
            ], stderr=subprocess.STDOUT, text=True)
            metadata = json.loads(raw)
            video = next((stream for stream in metadata.get("streams", []) if stream.get("codec_type") == "video"), None)
            if not video:
                raise ValueError("no readable video stream")
            duration = float(metadata.get("format", {}).get("duration", 0))
            if duration <= 0:
                raise ValueError("duration is missing or zero")
        except Exception as exc:
            failures.append((filename, str(exc)))

    print(f"Checked {len(files)} MP4 assets; {len(files) - len(failures)} valid; {len(failures)} invalid.")
    for filename, error in failures:
        print(f"FAIL {os.path.relpath(filename, PUBLIC_DIR)}: {error}")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
